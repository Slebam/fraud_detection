# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 07:29:05 2019

@author: EBZC0325
"""
import numpy as np
from WindPy import *
from openpyxl import load_workbook
import xlwt
workbook = load_workbook('examples_candi.xlsx')       
booksheet1 = workbook.get_sheet_by_name('control')
booksheet2 = workbook.get_sheet_by_name('candi')
list_of_candi=[]
total_num=0

def get_last_year_date(date):
    last_year_date=str(int(date)-10000)
    return last_year_date

def write_excel():
    f = xlwt.Workbook()
    sheet1 = f.add_sheet('Sheet1',cell_overwrite_ok=True)
    for i in range(0,len(stock_features)):
        for k in range(0,len(stock_features[i])):
            sheet1.write(i,k,stock_features[i][k])
    f.save('good_exmp_features.xls')

w.start()
w.isconnected()
stock_features=[]
ct_num=0
for j in range(2,2659):    
    for i in range(2,128):
        #line1=[booksheet1.cell(row=i, column=1).value,booksheet1.cell(row=i, column=2).value]
        #if(booksheet1.cell(row=i, column=2).value==booksheet2.cell(row=j, column=3).value):
        if(booksheet1.cell(row=i, column=2).value==booksheet2.cell(row=j, column=3).value and booksheet2.cell(row=j, column=2).value[0:4]<booksheet1.cell(row=i, column=1).value[0:4] and int(booksheet1.cell(row=i, column=1).value[0:4])>2002):    
            for date_good in range(int(booksheet1.cell(row=i, column=1).value[0:4]),min(int(booksheet1.cell(row=i, column=1).value[0:4])+3,2018)):
            #for date_good in range(2016,2018):
                #code:booksheet2.cell(row=j, column=1).value
                #date:date_good
                #print(date_good,booksheet2.cell(row=j, column=1).value,booksheet2.cell(row=j, column=3).value)
                ct_num+=1
                print(ct_num)
                # #here we retrieve data
                
                rpttime=str(date_good)+'1231'
                stock_code=booksheet2.cell(row=j, column=1).value
                dr=w.wss(stock_code,
                          "quick,\
                          grossprofitmargin,\
                          monetary_cap,\
                          inventories,\
                          tot_cur_assets,\
                          fa_curassetsratio,\
                          fa_intangassetratio,\
                          tot_oper_rev,\
                          net_profit_is,\
                          acct_rcv,\
                          ocftooperateincome,\
                          prepay,\
                          oth_rcv,\
                          roe,\
                          arturn,\
                          invturn,\
                          assetsturn1,\
                          yoyprofit,\
                          yoyop,\
                          yoyocf,\
                          np_belongto_parcomsh,\
                          stmnote_audit_category,\
                          holder_sumpcttop5",\
                          "rptDate={};unit=1;rptType=1;tradeDate={};zoneType=1;ShowBlank=kongzhi666".format(rpttime,rpttime))
                #print(rpttime)
                #print(get_last_year_date(rpttime))
                print(rpttime,stock_code)
                dr_last_yr=w.wss(stock_code,
                          "net_profit_is",\
                          "rptDate={};unit=1;rptType=1;tradeDate={};zoneType=1;ShowBlank=kongzhi666".format(get_last_year_date(rpttime),get_last_year_date(rpttime)))
                last_yr_is_lost=0
                if dr_last_yr.Data[0][0]<0: 
                    last_yr_is_lost=1
                audit_info=0
                if (('无保留' in dr.Data[21][0])!=1):
                    audit_info=1
                    print("Notice!Audit info!",stock_code)
                if(dr.Data[4][0]*dr.Data[7][0]!=0):
                    slice = np.array([dr.Data[0][0],\
                                   dr.Data[1][0],\
                                   dr.Data[3][0]/dr.Data[4][0],\
                                   dr.Data[5][0],\
                                   dr.Data[6][0],\
                                   dr.Data[9][0]/dr.Data[7][0],\
                                   dr.Data[10][0],\
                                   dr.Data[9][0]/dr.Data[4][0],\
                                   dr.Data[11][0]/dr.Data[4][0],\
                                   dr.Data[12][0]/dr.Data[4][0],\
                                   dr.Data[13][0],\
                                   dr.Data[14][0],\
                                   dr.Data[15][0],\
                                   dr.Data[16][0],\
                                   dr.Data[17][0],\
                                   dr.Data[18][0],\
                                   dr.Data[19][0],\
                                   last_yr_is_lost,\
                                   audit_info,\
                                   dr.Data[22][0],\
                                   booksheet2.cell(row=j, column=3).value,\
                                   0\
                                   ])  
                    stock_features.append(slice)
              
            break
def write_excel():
    f = xlwt.Workbook()
    sheet1 = f.add_sheet('Sheet1',cell_overwrite_ok=True)
    for i in range(0,len(stock_features)):
        for k in range(0,len(stock_features[i])):
            sheet1.write(i,k,stock_features[i][k])
    f.save('fake_exmp_features.xls')

write_excel()    


