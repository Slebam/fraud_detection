# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
##from WindPy import *
from WindPy import *
from pandas import Series,DataFrame
import numpy as np
import pandas as pd
import os
from openpyxl import load_workbook
import xlwt
def get_last_year_date(date):
    last_year_date=str(int(date)-10000)
    return last_year_date
#read excel
workbook = load_workbook('gross_samples.xlsx')       
booksheet = workbook.get_sheet_by_name('Sheet1')
list_of_stk=[]

for i in range(2,3744):##here should be 140 in total fakes
    rpttime_raw=booksheet.cell(row=i, column=3).value
    #print(type(rpttime_raw))
    #.value[0:4]+'1231'
    line=[booksheet.cell(row=i, column=1).value,rpttime_raw,booksheet.cell(row=i, column=6).value,booksheet.cell(row=i, column=8).value,1]
    list_of_stk.append(line)
#print(list_of_stk)


w.start()
w.isconnected()
stock_features=[]
ct_num=0
for stock in list_of_stk:
    stock_code=stock[0]
    rpttime=stock[1][0:4]+'1231'
    dr=w.wss(stock_code,
              "quick,\
              grossprofitmargin,\
              monetary_cap,\
              inventories,\
              tot_cur_assets,\
              fa_curassetsratio,\
              fa_intangassetratio,\
              tot_oper_rev,\
              net_profit_is,\
              acct_rcv,\
              ocftooperateincome,\
              prepay,\
              oth_rcv,\
              roe,\
              arturn,\
              invturn,\
              assetsturn1,\
              yoyprofit,\
              yoyop,\
              yoyocf,\
              np_belongto_parcomsh,\
              stmnote_audit_category,\
              holder_sumpcttop5",\
              "rptDate={};unit=1;rptType=1;tradeDate={};zoneType=1;ShowBlank=kongzhi666".format(rpttime,rpttime))
    #print(rpttime)
    #print(get_last_year_date(rpttime))
    dr_last_yr=w.wss(stock_code,
              "net_profit_is",\
              "rptDate={};unit=1;rptType=1;tradeDate={};zoneType=1;ShowBlank=kongzhi666".format(get_last_year_date(rpttime),get_last_year_date(rpttime)))
    last_yr_is_lost=0
    if dr_last_yr.Data[0][0]<0: 
        last_yr_is_lost=1
    audit_info=0
    if (dr.Data[21][0]!='标准无保留意见'):
        audit_info=1
        print("Notice!Audit info!"+stock_code)
    if(dr.Data[4][0]*dr.Data[7][0]!=0):
        slice = np.array([dr.Data[0][0],\
                       dr.Data[1][0],\
                       dr.Data[3][0]/dr.Data[4][0],\
                       dr.Data[5][0],\
                       dr.Data[6][0],\
                       dr.Data[9][0]/dr.Data[7][0],\
                       dr.Data[10][0],\
                       dr.Data[9][0]/dr.Data[4][0],\
                       dr.Data[11][0]/dr.Data[4][0],\
                       dr.Data[12][0]/dr.Data[4][0],\
                       dr.Data[13][0],\
                       dr.Data[14][0],\
                       dr.Data[15][0],\
                       dr.Data[16][0],\
                       dr.Data[17][0],\
                       dr.Data[18][0],\
                       dr.Data[19][0],\
                       last_yr_is_lost,\
                       audit_info,\
                       dr.Data[22][0],\
                       stock[0],\
                       stock[3]\
                       ])  
    #print(stock_code)
    ct_num+=1
    print(ct_num)
    print(slice)
    stock_features.append(slice)
print(stock_features)

def write_excel():
    f = xlwt.Workbook()
    sheet1 = f.add_sheet('Sheet1',cell_overwrite_ok=True)
    for i in range(0,len(stock_features)):
        for k in range(0,len(stock_features[i])):
            sheet1.write(i,k,stock_features[i][k])
    f.save('gross_samples_features.xls')

write_excel()
