from WindPy import *
from pandas import Series,DataFrame
import numpy as np
import pandas as pd
import os
from openpyxl import load_workbook
import xlwt
workbook = load_workbook('tot_exmp_features.xlsx')       
booksheet_fake = workbook['fake']
booksheet_good= workbook['good']
list_of_fake=[]
list_of_good=[]
for i in range(1,125):##here should be 140 in total fakes
    line=[]
    for k in range(1,23):
        line.append(float(booksheet_fake.cell(row=i, column=k).value))      
    list_of_fake.append(np.array(line))

for i in range(1,3922):##here should be 3921 in total fakes
    line=[]
    for k in range(1,23):
        line.append(float(booksheet_good.cell(row=i, column=k).value))      
    list_of_good.append(np.array(line))

feature_array_fake=np.array(list_of_fake)
feature_array_good=np.array(list_of_good)
ind_type=np.unique(feature_array_fake[:,20])
#print(feature_array_fake[:,20].size)
#print(feature_array_good[:,20].size)
#print(np.unique(feature_array_fake[:,20]).size)

ind_median=[]
for ind in ind_type:
    for col_num in range(0,17):
        temp_feature=[]
        for exemp_num in np.where(feature_array_good==ind)[0]:
            temp_feature.append(feature_array_good[exemp_num][col_num])
            temp_array_feature=np.array(temp_feature)
        #ind_median.append(np.median(temp_array_feature))
        ind_median.append(np.mean(temp_array_feature))
        ind_median.append(np.std(temp_array_feature,ddof=1))
    ind_median.append(ind)
std_ind_features=np.array(ind_median).reshape(46,35)

def write_excel(std_ind_features,name):
    f = xlwt.Workbook()
    sheet1 = f.add_sheet('Sheet1',cell_overwrite_ok=True)
    for i in range(0,len(std_ind_features)):
        for k in range(0,len(std_ind_features[i])):
            sheet1.write(i,k,std_ind_features[i][k])
    f.save(name)


std_feature_fake=[]
std_feature_good=[]

def standarization_features(feature_array_fake,std_ind_features):
    std_features=[]
    for one_exp in feature_array_fake:   
        ind_num=np.where(std_ind_features==one_exp[20])[0][0]
        new_fea_list=[]
        for fea_num in range(0,17):    
            new_fea=(one_exp[fea_num]-std_ind_features[ind_num][fea_num*2])/std_ind_features[ind_num][fea_num*2+1]
            new_fea_list.append(new_fea)
        for fea_num in range(17,22): 
            new_fea_list.append(one_exp[fea_num])
        std_features.append(new_fea_list)
    return std_features

std_feature_fake=standarization_features(feature_array_fake,std_ind_features)
std_feature_good=standarization_features(feature_array_good,std_ind_features)


write_excel(std_feature_fake,'std_feature_fake.xls') 
write_excel(std_feature_good,'std_feature_good.xls')
write_excel(std_ind_features,'std_ind_features.xls')