from WindPy import *
from pandas import Series,DataFrame
import numpy as np
import pandas as pd
import os
from openpyxl import load_workbook
import xlwt
workbook = load_workbook('tot_exmp_features.xlsx')       
booksheet_fake = workbook['fake']
booksheet_good= workbook['good']
list_of_fake=[]
list_of_good=[]
for i in range(1,125):##here should be 140 in total fakes
    line=[]
    for k in range(1,23):
        line.append(float(booksheet_fake.cell(row=i, column=k).value))      
    list_of_fake.append(np.array(line))

for i in range(1,3922):##here should be 3921 in total fakes
    line=[]
    for k in range(1,23):
        line.append(float(booksheet_good.cell(row=i, column=k).value))      
    list_of_good.append(np.array(line))

feature_array_fake=np.array(list_of_fake)
feature_array_good=np.array(list_of_good)
ind_type=np.unique(feature_array_fake[:,20])
#print(feature_array_fake[:,20].size)
#print(feature_array_good[:,20].size)
#print(np.unique(feature_array_fake[:,20]).size)

ind_median=[]
for ind in ind_type:
    for col_num in range(0,17):
        temp_feature=[]
        for exemp_num in np.where(feature_array_good==ind)[0]:
            temp_feature.append(feature_array_good[exemp_num][col_num])
            temp_array_feature=np.array(temp_feature)
        #ind_median.append(np.median(temp_array_feature))
        ind_median.append(np.mean(temp_array_feature))
        ind_median.append(np.std(temp_array_feature,ddof=1))
    ind_median.append(ind)
std_features=np.array(ind_median).reshape(46,35)
print(std_features)
# def write_excel():
    # f = xlwt.Workbook()
    # sheet1 = f.add_sheet('Sheet1',cell_overwrite_ok=True)
    # for i in range(0,len(std_features)):
        # for k in range(0,len(std_features[i])):
            # sheet1.write(i,k,std_features[i][k])
    # f.save('features_median.xlsx')

# write_excel()  
#for one_fea in feature_array_fake:
one_fea=feature_array_fake[0]
print('test')
print(np.where(ind_median==one_fea[20]))
    
    


