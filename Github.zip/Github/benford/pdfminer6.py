# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:33:39 2019

@author: EBZC0325
"""

from pdfminer import pdf2txt.py
#help(pdf2txt.py)