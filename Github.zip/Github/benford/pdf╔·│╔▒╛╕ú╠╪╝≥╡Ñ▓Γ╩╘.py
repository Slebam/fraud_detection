# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 19:42:52 2019

@author: EBZC0325
"""
import matplotlib.pyplot as plt
import numpy as np
import re
import sys
import os
import xlwt
path = "good_annual_reports_txt/" #文件夹目录
files= os.listdir(path) #得到文件夹下的所有文件名称
s = []
digit_frequency=[]
for file_ini in files: #遍历文件夹
     if not os.path.isdir(file_ini): #判断是否是文件夹，不是文件夹才打开
          if (os.path.splitext(file_ini)[-1]=='.txt'):
            filename=os.path.splitext(file_ini)[0]
            file = open(path+file_ini,encoding='gb18030',errors='ignore')
            s = file.read()
            #print(len(s))
            s1 = s.split()
            #print(len(s1))
            ct=1
            result=list()
            frequency = np.zeros(9,dtype=np.int)
            for k in s1:
                if len(k)>4 and k[0].isdigit() and k[len(k)-1].isdigit():
                    #print('number is ',ct,k)
                    sys.stdin.read()                 
                    ct=ct+1
                    result.append(k[0])
            #print('result is:',result,'length is',len(result))
            for digit in result:
                digit_int=int(digit)
                frequency[digit_int-1]+=1
            digit_frequency.append(frequency/ct)
            t = np.arange(1, 10)
            plt.plot(t, frequency, 'r-', t, frequency, 'go', lw=2, markersize=8)
            for x,y in enumerate(frequency):
                plt.text(x+1.1, y, frequency[x], verticalalignment='top', fontsize=15)
            plt.title("%s"%filename, fontsize=18)
            plt.xlim(0.5, 9.5)
            plt.ylim(0, max(frequency)*1.03)
            plt.grid(b=True)
            plt.show()
print(digit_frequency)


def write_excel():
    f = xlwt.Workbook()
    sheet1 = f.add_sheet('Sheet1',cell_overwrite_ok=True)
    for i in range(0,len(digit_frequency)):
        for k in range(0,len(digit_frequency[i])):
            sheet1.write(i,k,digit_frequency[i][k])
    f.save('frequency_result_2.xls')

if __name__ == '__main__':
	write_excel()