# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 19:41:53 2019

@author: EBZC0325
"""
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from time import time
from scipy.special import factorial
import math

t = np.arange(1, 10)
frequency = np.zeros(9, dtype=np.double)
list=[]
for s in range(0,9):
    print(math.log((s+2)/(s+1),10))
    s+=1
    num=round(math.log((s+2)/(s+1),10),4)
    print(round(2.235646,2))
    list.append(num)
frequency = np.array(list)
plt.plot(t, frequency, 'r-', t, frequency, 'go', lw=2, markersize=8)
for x,y in enumerate(frequency):
    plt.text(x+1.1, y, frequency[x], verticalalignment='top', fontsize=15)
plt.title(u'自然累积首位数字出现频率' , fontsize=18)
plt.xlim(0.5, 9.5)
plt.ylim(0, max(frequency)*1.03)
plt.grid(b=True)
plt.show()