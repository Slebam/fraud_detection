# -*- coding: utf-8 -*-
"""
Created on Sat Nov 23 10:06:44 2019

@author: EBZC0325
"""

from openpyxl import load_workbook
from numpy import *
from pathlib import Path
import requests
import matplotlib.pyplot as plt
import numpy as np
import re
import sys
import chardet
import datetime

# def create_assist_date(datestart = None,dateend = None):
	# # 创建日期辅助表
	# # 转为日期格式
	# datestart=datetime.datetime.strptime(datestart,'%Y-%m-%d')
	# dateend=datetime.datetime.strptime(dateend,'%Y-%m-%d')
	# date_list = []
	# date_list.append(datestart.strftime('%Y-%m-%d'))
	# while datestart<dateend:
		# # 日期叠加一天
	    # datestart+=datetime.timedelta(days=+1)
	    # # 日期转字符串存入列表
	    # date_list.append(datestart.strftime('%Y-%m-%d'))
	# return date_list
# #create_assist_date("2018-06-28","2018-07-28")

workbook = load_workbook('good_xmps.xlsx')       
booksheet = workbook.get_sheet_by_name('Sheet1')
list_of_stk=[]
for i in range(2,152):##here should be 140 in total fakes
    line=[booksheet.cell(row=i, column=1).value,booksheet.cell(row=i, column=3).value,booksheet.cell(row=i, column=4).value]
    list_of_stk.append(line)
#print(list_of_stk)

for stk in list_of_stk:  
     print(type(stk[0])) 
     print('aaa')
     name1=stk[0]+'_'+stk[1][0:4]     
     next_yr=str(int(stk[1][0:4])+1)
     url='http://www.sse.com.cn/disclosure/listedinfo/announcement/c/'+stk[2]+'/'+stk[0][0:6]+'_'+stk[1][0:4]+'_n.pdf'
     response = requests.get(url)
     filename = Path('good_annual_reports/'+name1+'.pdf')
     filename.write_bytes(response.content)    
     print("url1111"+url)
#     if (response.status_code!=404):
#        filename.write_bytes(response.content)    
#        print("url1111"+url)
#        continue
#     else:
#        print('we are doing'+stk[0][0:6])
#        date_list=create_assist_date(stk[2][0:4]+'-01-01',stk[2][0:4]+'-12-31')
#        for date_potent in date_list:
#            url2='http://www.sse.com.cn/disclosure/listedinfo/announcement/c/'+date_potent+'/'+stk[0][0:6]+'_'+stk[1][0:4]+'_n.pdf'
#            response = requests.get(url2)
#            print(url2)
#            if (response.status_code!=404):
#                filename.write_bytes(response.content)    
#                break              
 