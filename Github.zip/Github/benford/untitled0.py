# -*- coding: utf-8 -*-
"""
Created on Tue Nov 19 10:11:29 2019

@author: EBZC0325
"""

from WindPy import *
w.start()
import numpy as np
import pandas as pd
history_data=w.wsd("010107.SH",
                   "sec_name,ytm_b,volume,duration,convexity,open,high,low,close,vwap", 
                   "2018-06-01", "2018-06-11", "returnType=1;PriceAdj=CP", usedf=True) 
print(history_data)