from pathlib import Path
import requests
import matplotlib.pyplot as plt
import numpy as np
import re
import sys
import chardet
from scipy.special import factorial
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号
#import pdf2txt
name1='me123123tadata'
url='http://www.sse.com.cn/disclosure/listedinfo/announcement/c/2012-04-11/601558_2011_n.pdf'
response = requests.get(url)
filename = Path(name1+'.pdf')
filename.write_bytes(response.content)



#Here we calculate Benford!
file = open('me123123tadata.txt',encoding='gb18030',errors='ignore')
print(type(file))
#print(chardet.detect(file))
s = file.read()
print(len(s))
print(type(s))
s1 = s.split()
print(len(s1))
ct=1
result=list()
frequency = np.zeros(9,dtype=np.int)
for k in s1:
    if len(k)>4 and k[0].isdigit() and k[len(k)-1].isdigit():
        #print('number is ',ct,k)
        sys.stdin.read()
        
        ct=ct+1
        result.append(k[0])
#print('result is:',result,'length is',len(result))
for digit in result:
    digit_int=int(digit)
    frequency[digit_int-1]+=1
t = np.arange(1, 10)
plt.plot(t, frequency, 'r-', t, frequency, 'go', lw=2, markersize=8)
for x,y in enumerate(frequency):
    plt.text(x+1.1, y, frequency[x], verticalalignment='top', fontsize=15)
plt.title(u'首位数字出现频率' , fontsize=18)
plt.xlim(0.5, 9.5)
plt.ylim(0, max(frequency)*1.03)
plt.grid(b=True)
plt.show()

