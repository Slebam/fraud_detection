from openpyxl import load_workbook
from numpy import *
from pathlib import Path
import requests
import matplotlib.pyplot as plt
import numpy as np
import re
import sys
import chardet
import datetime


workbook = load_workbook('fake_xmps.xlsx')       
booksheet = workbook.get_sheet_by_name('Sheet1')
list_of_stk=[]
for i in range(2,60):##here should be 140 in total fakes
    line=[booksheet.cell(row=i, column=1).value,booksheet.cell(row=i, column=3).value,booksheet.cell(row=i, column=4).value]
    list_of_stk.append(line)
#print(list_of_stk)
address_list=[]
for stk in list_of_stk:  
     name1=stk[0]+'_'+stk[1][0:4]     
     next_yr=str(int(stk[1][0:4])+1)
     url='http://www.sse.com.cn/disclosure/listedinfo/announcement/c/'+stk[2]+'/'+stk[0][0:6]+'_'+stk[1][0:4]+'_n.pdf'
     address_list.append(url)
for k in address_list:
    print(k)